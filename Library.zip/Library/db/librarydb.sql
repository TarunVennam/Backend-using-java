-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2024 at 09:58 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `librarydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `availability` varchar(20) NOT NULL DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `title`, `author`, `availability`) VALUES
(1, 'Java Programming', 'Gaga', 'Available'),
(2, 'Database Systems', 'Dwayne', 'Borrowed'),
(3, 'Web Development', 'Rasmus', 'Available'),
(4, 'gg', 'gg', 'Available'),
(7, 'ppppp', 'ooooo', 'Available'),
(8, 'yeeego', 'oyaaa', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `borrowedbooks`
--

CREATE TABLE `borrowedbooks` (
  `borrow_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrow_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `return_date` timestamp NULL DEFAULT NULL,
  `returned` tinyint(4) NOT NULL DEFAULT 0,
  `mailed` tinyint(4) NOT NULL DEFAULT 0,
  `fine` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrowedbooks`
--

INSERT INTO `borrowedbooks` (`borrow_id`, `user_id`, `book_id`, `borrow_date`, `return_date`, `returned`, `mailed`, `fine`) VALUES
(6, 2, 1, '2024-07-25 19:36:15', '2024-07-22 15:31:17', 1, 1, 9000),
(7, 2, 2, '2024-07-25 17:23:12', '2024-07-25 15:54:06', 1, 0, 0),
(11, 2, 2, '2024-07-25 17:23:12', '2024-07-22 17:17:44', 1, 0, 0),
(12, 2, 3, '2024-07-25 17:25:26', '2024-07-26 17:25:13', 1, 0, 0),
(13, 2, 2, '2024-07-25 19:36:18', '2024-07-21 18:07:32', 0, 1, 14000);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `user_id`, `message`, `date`) VALUES
(1, 2, 'Your request for the book with ID 6 has been denied.', '2024-07-25 19:02:58'),
(2, 2, 'Your request for the book with ID 3 has been approved.', '2024-07-25 19:08:20'),
(3, 2, 'Your request for the book with ID 7 has been approved.', '2024-07-25 19:08:25'),
(4, 2, 'Your request for the book with ID 2 has been approved.', '2024-07-25 19:10:35'),
(5, 2, 'Your request for the book with ID 3 has been denied.', '2024-07-25 19:10:38'),
(6, 2, 'Your request for the book has been approved.', '2024-07-25 19:17:44'),
(7, 2, 'Book returned successfully.', '2024-07-25 19:23:12'),
(8, 2, 'Your request for the book has been approved.', '2024-07-25 19:25:13'),
(9, 2, 'Book returned successfully.', '2024-07-25 19:25:26'),
(10, 2, 'Your request for the book has been approved.', '2024-07-25 20:07:32'),
(11, 2, 'Book returned successfully.', '2024-07-25 21:36:15');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `request_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `request_date` datetime DEFAULT NULL,
  `status` enum('Pending','Approved','Denied') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`request_id`, `user_id`, `book_id`, `request_date`, `status`) VALUES
(2, 2, 4, '2024-07-25 18:44:19', 'Denied'),
(4, 2, 3, '2024-07-25 18:51:28', 'Approved'),
(5, 2, 7, '2024-07-25 18:51:34', 'Approved'),
(7, 2, 2, '2024-07-25 19:10:17', 'Approved'),
(8, 2, 3, '2024-07-25 19:10:20', 'Denied'),
(9, 2, 2, '2024-07-25 19:17:32', 'Approved'),
(10, 2, 3, '2024-07-25 19:24:57', 'Approved'),
(11, 2, 2, '2024-07-25 20:07:19', 'Approved'),
(12, 2, 4, '2024-07-25 21:11:32', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('admin','staff','student','normal_user') NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`, `email`) VALUES
(1, 'niyo', '123', 'admin', 'niyizigihe16@gmail.com'),
(2, 'chance', '123', 'student', 'niyevar85@gmail.com'),
(3, 'jaj', 'jaj', 'staff', 'niyevar85@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `borrowedbooks`
--
ALTER TABLE `borrowedbooks`
  ADD PRIMARY KEY (`borrow_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `borrowedbooks_ibfk_2` (`book_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `requests_ibfk_2` (`book_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `borrowedbooks`
--
ALTER TABLE `borrowedbooks`
  MODIFY `borrow_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrowedbooks`
--
ALTER TABLE `borrowedbooks`
  ADD CONSTRAINT `borrowedbooks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `borrowedbooks_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
